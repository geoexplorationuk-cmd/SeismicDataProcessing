# Example 2 — 3D/UGR Seismic Imaging with Anelastic / Viscoelastic Parameters

Compact synthetic research package for comparing elastic, anelastic and viscoelastic-style 3D seismic images in an AUV-oriented UGR workflow.

## Run
```bash
pip install -r requirements.txt
python run_example.py
```

## Included outputs
- `outputs/3d_ugr_volumes.npz`: raw, elastic, anelastic and viscoelastic cubes plus Vp, density, Qp, Qs and layer IDs.
- PNG inline, crossline and depth-slice comparisons for all three cases.
- Vp, density, Qp and Qs model visualizations.
- `outputs/QA_QC_3D_UGR_Report.txt`: layer model statistics, SNR, PSNR, global SSIM-style metric, amplitude preservation and QA/QC findings.
- `outputs/layer_model_summary.csv`: layer-wise parameter summary.

## Workflow
1. Generate synthetic 3D geological volume.
2. Build spatially varying velocity and density models.
3. Assign spatially varying Qp and Qs.
4. Generate a synthetic reflectivity cube.
5. Compare elastic, anelastic and viscoelastic-style responses.
6. Export image slices and QA/QC report.

## Scientific scope
This is a lightweight synthetic demonstration, not a full 3D elastic/viscoelastic wave-equation solver or true migration implementation. Attenuation is a simplified frequency-domain proxy. No SEG-Y reader, AUV navigation/georeferencing, anisotropy, calibrated acquisition geometry or depth conversion is included. A real AUV survey requires navigation, attitude, altitude, sound-speed and sensor metadata QC.

Author: MATTEO MIRABILIO
