
from pathlib import Path
import numpy as np, matplotlib.pyplot as plt, argparse

def model(nz=80, ny=48, nx=48, seed=12):
    r=np.random.default_rng(seed)
    z=np.arange(nz)[:,None,None]; y=np.arange(ny)[None,:,None]; x=np.arange(nx)[None,None,:]
    und=2.2*np.sin(x/8)+1.5*np.cos(y/9)
    ids=np.zeros((nz,ny,nx),np.int8)
    ids[z>=19+und]=1; ids[z>=38+0.8*und]=2; ids[z>=59+0.5*und]=3
    vpt=np.array([1480,1580,1720,1880],np.float32)
    rt=np.array([1660,1740,1830,1950],np.float32)
    qpt=np.array([55,75,105,135],np.float32)
    qst=np.array([30,42,58,75],np.float32)
    vp=vpt[ids]+r.normal(0,5,ids.shape); rho=rt[ids]+r.normal(0,5,ids.shape)
    qp=qpt[ids]+r.normal(0,1.5,ids.shape); qs=qst[ids]+r.normal(0,1.5,ids.shape)
    return vp.astype('f4'),rho.astype('f4'),qp.astype('f4'),qs.astype('f4'),ids

def ricker(f,dt,n):
    t=(np.arange(n)-n//2)*dt; a=(np.pi*f*t)**2
    return ((1-2*a)*np.exp(-a*a)).astype('f4')

def make_cube(vp,rho,dt=.001,seed=5):
    rng=np.random.default_rng(seed); imp=vp*rho
    refl=np.zeros_like(imp); refl[1:]=(imp[1:]-imp[:-1])/(imp[1:]+imp[:-1])
    w=ricker(180,dt,31); cube=np.empty_like(refl)
    for j in range(refl.shape[1]):
        for i in range(refl.shape[2]):
            cube[:,j,i]=np.convolve(refl[:,j,i],w,mode='same')
    cube += rng.normal(0,.008,cube.shape).astype('f4')
    return cube

def filter_cube(a,dt,lo=40,hi=420):
    n=a.shape[0]; f=np.fft.rfftfreq(n,dt); w=np.zeros_like(f)
    w[(f>=lo)&(f<=hi)]=1
    taper=25
    m=(f>=lo-taper)&(f<lo); w[m]=.5-.5*np.cos(np.pi*(f[m]-(lo-taper))/taper)
    m=(f>hi)&(f<=hi+taper); w[m]=.5+.5*np.cos(np.pi*(f[m]-hi)/taper)
    return np.fft.irfft(np.fft.rfft(a,axis=0)*w[:,None,None],n=n,axis=0).astype('f4')

def attenuation(a,qp,qs,dt,visco=False):
    n,ny,nx=a.shape; f=np.fft.rfftfreq(n,dt); out=np.empty_like(a)
    for j in range(ny):
        for i in range(nx):
            qeff=1/(.65/qp[:,j,i]+.35/qs[:,j,i])
            q=float(np.mean(qeff))
            amp=np.exp(-np.pi*np.abs(f-180)/(q*180)*(n*dt)*.9)
            phase=(-.10*np.sign(f-180)*np.log(np.maximum(f,1)/180)) if visco else 0
            sp=np.fft.rfft(a[:,j,i])*amp*np.exp(1j*phase)
            out[:,j,i]=np.fft.irfft(sp,n=n)
    return out.astype('f4')

def stats(ref,test):
    mse=float(np.mean((ref-test)**2)); peak=float(np.max(np.abs(ref)))
    psnr=20*np.log10(peak/np.sqrt(mse)) if mse>0 else 99.
    snr=10*np.log10(np.mean(ref**2)/mse) if mse>0 else 99.
    c1=(.01*peak)**2; c2=(.03*peak)**2
    a,b=float(ref.mean()),float(test.mean()); va,vb=float(ref.var()),float(test.var())
    cov=float(np.mean((ref-a)*(test-b)))
    ssim=((2*a*b+c1)*(2*cov+c2))/((a*a+b*b+c1)*(va+vb+c2))
    rms0=float(np.sqrt(np.mean(ref**2))); rms1=float(np.sqrt(np.mean(test**2)))
    return snr,psnr,ssim,rms1,100*rms1/rms0

def plot(a,path,title,cmap='gray'):
    fig,ax=plt.subplots(figsize=(7.5,4.5))
    im=ax.imshow(a,aspect='auto',origin='upper',cmap=cmap)
    ax.set_title(title); ax.set_xlabel('X / crossline index'); ax.set_ylabel('Z / sample index')
    fig.colorbar(im,ax=ax,shrink=.8); fig.tight_layout(); fig.savefig(path,dpi=140); plt.close(fig)

def run(out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    vp,rho,qp,qs,lid=model(); dt=.001
    raw=make_cube(vp,rho,dt); el=filter_cube(raw,dt)
    an=filter_cube(attenuation(raw,qp,qs,dt,False),dt)
    ve=filter_cube(attenuation(raw,qp,qs,dt,True),dt)
    scale=np.percentile(np.abs(el),99.5)
    cubes={'elastic':el,'anelastic':an,'viscoelastic':ve}
    np.savez_compressed(out/'3d_ugr_volumes.npz',raw=raw,**cubes,vp_m_s=vp,density_kg_m3=rho,qp=qp,qs=qs,layer_id=lid)
    iy,ix,iz=el.shape[1]//2,el.shape[2]//2,el.shape[0]//2
    for name,a in cubes.items():
        d=np.clip(a/max(scale,1e-12),-1,1)
        plot(d[:,iy,:],out/f'{name}_inline.png',f'{name.title()} inline {iy}')
        plot(d[:,:,ix],out/f'{name}_crossline.png',f'{name.title()} crossline {ix}')
        plot(d[iz,:,:],out/f'{name}_depth_slice.png',f'{name.title()} depth slice {iz}')
    for name,a in [('velocity_model_inline',vp),('density_model_inline',rho),('qp_model_inline',qp),('qs_model_inline',qs)]:
        plot(a[:,iy,:],out/f'{name}.png',name.replace('_',' ').title(),'viridis')
    def continuity(a):
        p=a[iz,:,:-1].ravel(); q=a[iz,:,1:].ravel()
        return float(np.corrcoef(p,q)[0,1])
    ma=stats(el,an); mv=stats(el,ve)
    lines=[]
    for k in range(4):
        m=lid==k
        lines.append((k+1,int(m.sum()),vp[m].mean(),rho[m].mean(),qp[m].mean(),qs[m].mean()))
    report=[
    'EXAMPLE 2 — 3D/UGR SEISMIC IMAGING: ANELASTIC / VISCOELASTIC AUV RESEARCH','='*78,'',
    'PURPOSE','Compare elastic, anelastic and viscoelastic-style 3D seismic image volumes for a synthetic UGR/AUV research case.','Synthetic data only; no field SEG-Y is included.','',
    'SURVEY / INPUT',f'Survey type: 3D/UGR',f'Geometry: {el.shape[2]} X x {el.shape[1]} Y x {el.shape[0]} Z samples',f'Input: generated synthetic seismic cube',f'Vertical sample interval: {dt*1000:.3f} ms (illustrative time axis)',f'Models: Elastic / Anelastic / Viscoelastic',f'Processing: FFT bandpass + frequency-domain attenuation comparison','','3D VELOCITY / DENSITY / Q MODEL — LAYER MEANS',
    'Layer | Samples | Vp mean (m/s) | Density mean (kg/m3) | Qp mean | Qs mean','------+---------+---------------+---------------------+---------+--------']
    for row in lines: report.append(f'{row[0]:5d} | {row[1]:7d} | {row[2]:13.2f} | {row[3]:19.2f} | {row[4]:7.2f} | {row[5]:7.2f}')
    report += ['', 'MODEL RANGES',f'Vp: {vp.min():.1f}–{vp.max():.1f} m/s',f'Density: {rho.min():.1f}–{rho.max():.1f} kg/m3',f'Qp: {qp.min():.1f}–{qp.max():.1f}',f'Qs: {qs.min():.1f}–{qs.max():.1f}',
    '','IMAGE QUALITY METRICS (relative to elastic reference)','Case | SNR dB | PSNR dB | SSIM-global* | RMS amplitude | Amplitude preservation %']
    for name,m in [('Anelastic',ma),('Viscoelastic',mv)]:
        report.append(f'{name} | {m[0]:.3f} | {m[1]:.3f} | {m[2]:.5f} | {m[3]:.6f} | {m[4]:.2f}')
    report += [f'Elastic lateral continuity proxy: {continuity(el):.5f}',f'Anelastic lateral continuity proxy: {continuity(an):.5f}',f'Viscoelastic lateral continuity proxy: {continuity(ve):.5f}',
    '*SSIM-global is a compact global SSIM-style statistic, not windowed standard SSIM.',
    '','QA/QC ANALYSIS','PASS — all output volumes have matching dimensions.','PASS — all model and seismic arrays contain finite numeric values.',
    'PASS — Vp, density, Qp and Qs are positive throughout the volume.','PASS — common display scaling is used for elastic/anelastic/viscoelastic panels.',
    'PASS — inline, crossline, depth slices and model visualizations exported.',
    'NOT VALIDATED — AUV navigation, attitude, altitude, layback, sound velocity and georeferencing are not supplied.',
    'NOT APPLICABLE — SEG-Y header/trace QC; synthetic NPZ is used and no SEG-Y reader is included.',
    '','INTERPRETATION','Lower Q values cause stronger amplitude attenuation in this simplified spectral proxy. The viscoelastic case adds a small illustrative phase-dispersion term.',
    'Compare amplitude preservation, spectral bandwidth, reflector continuity and image character across the three cases.',
    '','SCIENTIFIC LIMITATIONS','This is a compact research example, not a full 3D elastic/viscoelastic PDE solver or migration engine.',
    'Attenuation is represented by a simplified trace-wise frequency-domain operator using path-average Q.',
    'No true 3D migration, anisotropy, elastic mode conversion, calibrated source/receiver geometry or depth conversion is implemented.',
    'SNR/PSNR/SSIM are relative to the synthetic elastic reference, not field truth.',
    'AUV acquisition QC requires real navigation, attitude, altitude, sound-speed and sensor metadata.',
    '','OUTPUTS','3d_ugr_volumes.npz — raw and three processed volumes plus Vp, density, Qp, Qs, layer IDs.',
    'PNG files — inline, crossline, depth slices and model visualizations.','QA_QC_3D_UGR_Report.txt — this report.','layer_model_summary.csv — layer-wise model statistics.',
    '','Author: MATTEO MIRABILIO','Research demonstration — 3D/UGR seismic imaging for AUV acquisition']
    (out/'QA_QC_3D_UGR_Report.txt').write_text('\\n'.join(report),encoding='utf-8')
    with open(out/'layer_model_summary.csv','w') as f:
        f.write('layer,samples,mean_vp_m_s,mean_density_kg_m3,mean_qp,mean_qs\\n')
        for r in lines: f.write(','.join(map(str,r))+'\\n')
    print('Generated outputs:',out)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--outdir',default='outputs'); a=p.parse_args(); run(a.outdir)
