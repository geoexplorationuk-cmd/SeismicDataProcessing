#!/usr/bin/env python3
"""
2D UHR seismic processing demo: wide-format CSV -> processed seismic image.
Dependencies: numpy, pandas, matplotlib
"""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def smooth_bandpass_fft(trace, dt_s, low_hz, high_hz, taper_hz):
    """FFT bandpass with cosine tapers; no SciPy required."""
    n = trace.size
    f = np.fft.rfftfreq(n, dt_s)
    spec = np.fft.rfft(trace)
    w = np.zeros_like(f)
    # low-frequency ramp
    lo0 = max(0.0, low_hz - taper_hz)
    lo1 = low_hz
    hi1 = high_hz
    hi2 = high_hz + taper_hz
    if taper_hz <= 0:
        w[(f >= low_hz) & (f <= high_hz)] = 1.0
    else:
        mid = (f >= lo1) & (f <= hi1)
        w[mid] = 1.0
        low = (f >= lo0) & (f < lo1)
        if np.any(low):
            z = (f[low] - lo0) / max(lo1-lo0, 1e-12)
            w[low] = 0.5 - 0.5*np.cos(np.pi*z)
        high = (f > hi1) & (f <= hi2)
        if np.any(high):
            z = (hi2-f[high]) / max(hi2-hi1, 1e-12)
            w[high] = 0.5 - 0.5*np.cos(np.pi*z)
    return np.fft.irfft(spec*w, n=n)

def process(data, dt_s, low_hz, high_hz, taper_hz, gain_power):
    # Remove trace-wise DC and apply zero-phase FFT bandpass.
    demeaned = data - np.mean(data, axis=0, keepdims=True)
    filtered = np.column_stack([
        smooth_bandpass_fft(demeaned[:, ix], dt_s, low_hz, high_hz, taper_hz)
        for ix in range(demeaned.shape[1])
    ])
    # Time gain (t^p), stabilized at t=0.
    t = np.arange(filtered.shape[0])*dt_s
    gain = np.maximum(t, dt_s)**gain_power
    gained = filtered*gain[:,None]
    # Robust global amplitude scaling for display.
    scale = np.percentile(np.abs(gained), 99.5)
    if scale > 0:
        display = np.clip(gained/scale, -1.0, 1.0)
    else:
        display = gained
    return filtered, gained, display

def main():
    parser = argparse.ArgumentParser(description="Process 2D UHR seismic CSV data.")
    parser.add_argument("--input", default="data/uhr_synthetic_input.csv")
    parser.add_argument("--outdir", default="outputs")
    parser.add_argument("--low", type=float, default=500.0, help="Bandpass low cut (Hz)")
    parser.add_argument("--high", type=float, default=6000.0, help="Bandpass high cut (Hz)")
    parser.add_argument("--taper", type=float, default=500.0, help="Cosine taper width (Hz)")
    parser.add_argument("--gain-power", type=float, default=0.7, help="Time gain exponent")
    args = parser.parse_args()

    input_path = Path(args.input)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    frame = pd.read_csv(input_path)
    if "time_ms" not in frame.columns:
        raise ValueError("CSV must contain a 'time_ms' column.")
    time_ms = frame["time_ms"].to_numpy(dtype=float)
    trace_cols = [c for c in frame.columns if c != "time_ms"]
    if len(trace_cols) < 2:
        raise ValueError("CSV must contain at least two trace columns.")
    data = frame[trace_cols].to_numpy(dtype=float)
    dt_s = np.median(np.diff(time_ms))*1e-3
    if dt_s <= 0:
        raise ValueError("time_ms must be strictly increasing.")

    filtered, gained, display = process(
        data, dt_s, args.low, args.high, args.taper, args.gain_power
    )

    # Save processed samples as wide CSV
    out_df = pd.DataFrame(display, columns=trace_cols)
    out_df.insert(0, "time_ms", time_ms)
    out_df.to_csv(outdir/"uhr_processed.csv", index=False, float_format="%.7f")

    # Metrics report
    metrics = pd.DataFrame([{
        "n_samples": data.shape[0],
        "n_traces": data.shape[1],
        "sample_interval_ms": float(np.median(np.diff(time_ms))),
        "bandpass_low_hz": args.low,
        "bandpass_high_hz": args.high,
        "gain_power": args.gain_power,
        "raw_rms": float(np.sqrt(np.mean(data**2))),
        "processed_rms": float(np.sqrt(np.mean(gained**2))),
        "display_clip_percentile": 99.5
    }])
    metrics.to_csv(outdir/"processing_report.csv", index=False)

    extent = [0, data.shape[1]-1, time_ms[-1], time_ms[0]]
    vmax = np.percentile(np.abs(data), 99.5)
    fig, ax = plt.subplots(figsize=(12, 7))
    im = ax.imshow(data, cmap="gray", aspect="auto", extent=extent,
                   vmin=-vmax, vmax=vmax, interpolation="nearest")
    ax.set_title("2D UHR Seismic — Raw CSV Input")
    ax.set_xlabel("Trace number")
    ax.set_ylabel("Two-way travel time (ms)")
    fig.colorbar(im, ax=ax, label="Amplitude")
    fig.tight_layout()
    fig.savefig(outdir/"uhr_raw.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(12, 7))
    im = ax.imshow(display, cmap="gray", aspect="auto", extent=extent,
                   vmin=-1, vmax=1, interpolation="nearest")
    ax.set_title(f"2D UHR Seismic — Processed | {args.low:g}-{args.high:g} Hz bandpass")
    ax.set_xlabel("Trace number")
    ax.set_ylabel("Two-way travel time (ms)")
    fig.colorbar(im, ax=ax, label="Normalized amplitude")
    fig.tight_layout()
    fig.savefig(outdir/"uhr_processed.png", dpi=180)
    plt.close(fig)

    print(f"Processed {data.shape[1]} traces x {data.shape[0]} samples")
    print(f"Outputs written to: {outdir.resolve()}")

if __name__ == "__main__":
    main()
