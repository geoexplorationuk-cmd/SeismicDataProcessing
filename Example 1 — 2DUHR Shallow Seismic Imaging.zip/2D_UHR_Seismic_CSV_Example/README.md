# 2D UHR Seismic Processing — CSV to Image

A complete, reproducible example of a **2D Ultra-High-Resolution (UHR) seismic processing workflow** using a wide-format CSV dataset and Python.

## Included

- `data/uhr_synthetic_input.csv` — synthetic 2D seismic section (120 traces × 900 samples)
- `process_uhr.py` — processing script
- `outputs/uhr_raw.png` — raw seismic image
- `outputs/uhr_processed.png` — processed seismic image
- `outputs/uhr_processed.csv` — normalized processed samples
- `outputs/processing_report.csv` — basic QC/processing metrics

The synthetic dataset contains layered reflections, a diffraction-like event and random noise. It is for demonstration only, not field data.

## Processing steps

1. Read CSV with `time_ms` and one column per trace.
2. Remove trace-wise DC component.
3. Apply zero-phase FFT bandpass with cosine tapers.
4. Apply time gain (`t^p`).
5. Robust amplitude normalization and clipping for display.
6. Export processed CSV, QC metrics and seismic section images.

## Requirements

Python 3.9+ and:

```bash
pip install numpy pandas matplotlib
```

## Run

From this directory:

```bash
python process_uhr.py
```

Custom processing parameters:

```bash
python process_uhr.py --input data/uhr_synthetic_input.csv --outdir outputs --low 500 --high 6000 --taper 500 --gain-power 0.7
```

## CSV format

Wide format: first column is `time_ms`; remaining columns are seismic traces.

```csv
time_ms,trace_001,trace_002,trace_003
0.00,0.01,-0.02,0.00
0.05,0.03,0.01,-0.01
...
```

All trace columns must have the same sample count. Time must be strictly increasing and evenly sampled for best FFT-filter performance.

## Output preview

- `outputs/uhr_raw.png`
- `outputs/uhr_processed.png`

## Important notes

- The default bandpass is 500–6000 Hz, appropriate as a **demonstration setting** for high-frequency shallow seismic data; adapt it to the actual acquisition bandwidth and sample interval.
- The script uses a simple FFT-domain bandpass, not a production-grade zero-phase Butterworth implementation.
- Time gain can amplify noise; inspect raw and processed sections together.
- No deconvolution, velocity analysis, NMO, migration, geometry assignment or true-amplitude recovery is performed.
- Results are illustrative and should not be interpreted as a validated field-processing product.

## Author

MATTEO MIRABILIO

Research example — Seismic Image Processing / 2D UHR
